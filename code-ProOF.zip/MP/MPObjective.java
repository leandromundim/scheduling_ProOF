/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ProOF.apl.sample1.problem.MP;

import ProOF.opt.abst.problem.meta.objective.SingleObjective;

/**
 *
 * @author mundim
 */
public class MPObjective extends SingleObjective<MP, cMP, MPObjective> {
    public MPObjective() throws Exception {
        super();
    }
    @Override
    public void evaluate(MP prob, cMP codif) throws Exception {
        double fitness = 0;
        int[][] aux = new int [prob.inst.M][2];  
        for(int j =0; j < prob.inst.M; j++){
            aux[j][0] = -1; //indice do ultimo item alocado na maquina j
            aux[j][1] = 0;  //makespan parcial da maquina j
        }

        for(int i : codif.path){
            double menorMakespan = 100000000;
            int idx = 0;
            for(int j =0; j < prob.inst.M; j++){
                if(menorMakespan > aux[j][1]){
                    menorMakespan = aux[j][1];
                    idx = j;
                }
            }
            if(aux[idx][0] > -1){
                aux[idx][1] += prob.inst.Cij[aux[idx][0]][i+1] + prob.inst.Cij[i][0];
            }
            else{
                aux[idx][1] += prob.inst.Cij[i][i+1] + prob.inst.Cij[i][0];
            }
            aux[idx][0] = i;
        }
        for(int j =0; j < prob.inst.M; j++){
            if( fitness < aux[j][1]) fitness = aux[j][1];
        }

        set(fitness);       //set de fitness to the ProOF
    }
    @Override
    public MPObjective build(MP prob) throws Exception {
        return new MPObjective();
    }
}
