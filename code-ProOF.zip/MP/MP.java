/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ProOF.apl.sample1.problem.MP;

import ProOF.com.Linker.LinkerApproaches;
import ProOF.com.Linker.LinkerParameters;
import ProOF.com.Linker.LinkerResults;
import ProOF.gen.best.BestSol;
import ProOF.opt.abst.problem.meta.Objective;
import ProOF.opt.abst.problem.meta.Problem;
import ProOF.opt.abst.problem.meta.codification.Codification;

/**
 *
 * @author mundim
 */
public class MP extends Problem<BestSol>{
    public final MPInstance inst = new MPInstance();
    
    
    @Override
    public String name() {
        return "MP";
    }
    @Override
    public Codification build_codif() throws Exception {
        return new cMP(this);
    }
    @Override
    public Objective build_obj() throws Exception {
        return new MPObjective();
    }
    @Override
    public void services(LinkerApproaches link) throws Exception {
        super.services(link);
        link.add(inst);
        link.add(MPOperator.obj);
    }
    @Override
    public BestSol best() {
        return BestSol.object();
    }
    @Override
    public void start() throws Exception {
        add_gap("gap", inst.optimal);
    }
}
