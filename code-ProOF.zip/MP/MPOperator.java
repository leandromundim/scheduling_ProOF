/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ProOF.apl.sample1.problem.MP;

import ProOF.com.Linker.LinkerParameters;
import ProOF.com.language.Factory;
import ProOF.gen.operator.oCrossover;
import ProOF.gen.operator.oGreedyConstruction;
import ProOF.gen.operator.oInitialization;
import ProOF.gen.operator.oLocalMove;
import ProOF.gen.operator.oMutation;
import ProOF.gen.operator.oTrailPheromone;
import ProOF.opt.abst.problem.meta.codification.Operator;
import ProOF.opt.abst.problem.meta.objective.SingleObjective;
import ProOF.utilities.uRoulette;
import ProOF.utilities.uRouletteList;
import ProOF.utilities.uUtil;
import java.util.LinkedList;
import java.util.Random;
import jsc.util.Arrays;

/**
 *
 * @author marcio
 */
public class MPOperator extends Factory<Operator>{
    public static final MPOperator obj = new MPOperator();
    
    @Override
    public String name() {
        return "MP Operators";
    }
    @Override
    public Operator build(int index) {  //build the operators
        switch(index){
            case 0: return new RandomScheduling();    //initialization
            case 1: return new MutExchange();   //mutation
            case 2: return new TwoPoints();     //crossover
            case 3: return new MovExchange();   //local movement
            case 4: return new OnePoint();     //crossover
        }
        return null;
    }
    
    private class RandomScheduling extends oInitialization<MP, cMP>{
        @Override
        public String name() {
            return "Random Scheduling";
        }
        @Override
        public void initialize(MP prob, cMP ind) throws Exception {
            for(int i=0; i<ind.path.length; i++){
                ind.path[i] = i;
            }
            for(int i=0; i<ind.path.length; i++){
                random_swap(prob.rnd, ind);
            }
        }
    }
    private class MutExchange extends oMutation<MP, cMP>{
        @Override
        public String name() {
            return "Mut-Exchange";
        }
        @Override
        public void mutation(MP prob, cMP ind) throws Exception {
            random_swap(prob.rnd, ind);
        }
    }
    private class MovExchange extends oLocalMove<MP, cMP>{
        @Override
        public String name() {
            return "Mov-Exchange";
        }
        @Override
        public void local_search(MP prob, cMP ind) throws Exception {
            random_swap(prob.rnd, ind);
            shift(prob.rnd, ind);
        }
    }
    private class TwoPoints extends oCrossover<MP, cMP>{
        @Override
        public String name() {
            return "TwoPoints";
        }
        @Override
        public cMP crossover(MP prob, cMP ind1, cMP ind2) throws Exception {
            cMP child = ind1.build(prob);
            int p[] = prob.rnd.cuts_points(prob.inst.N, 2);
            boolean selected[] = new boolean[prob.inst.N];
            for(int i=p[0]; i<p[1]; i++){
                child.path[i] = ind1.path[i];
                selected[child.path[i]] = true;
            }
            int i=p[1];
            int j=p[1];
            while(i!=p[0]){
                while(selected[ind2.path[j]]){
                    j = (j+1) % prob.inst.N;
                }
                child.path[i] = ind2.path[j];
                selected[child.path[i]] = true;
                i = (i+1) % prob.inst.N;
            }
            return child;
        }
    }

    private class OnePoint extends oCrossover<MP, cMP>{
        @Override
        public String name() {
            return "OnePoint";
        }
        @Override
        public cMP crossover(MP prob, cMP ind1, cMP ind2) throws Exception {
            cMP child = ind1.build(prob);
            int p[] = prob.rnd.cuts_points(prob.inst.N, 2);
            p[0] = 0;
            p[1] = (int) Math.ceil(prob.inst.N/2);
            boolean selected[] = new boolean[prob.inst.N];
            for(int i=p[0]; i<p[1]; i++){
                child.path[i] = ind1.path[i];
                selected[child.path[i]] = true;
            }
            int i=p[1];
            int j=p[1];
            while(i!=p[0]){
                while(selected[ind2.path[j]]){
                    j = (j+1) % prob.inst.N;
                }
                child.path[i] = ind2.path[j];
                selected[child.path[i]] = true;
                i = (i+1) % prob.inst.N;
            }
            return child;
        }
    }
  
    
    private static void random_swap(Random rmd, cMP ind){
        int a =  rmd.nextInt(ind.path.length);
        int b =  rmd.nextInt(ind.path.length);
        int aux = ind.path[a];
        ind.path[a] = ind.path[b];
        ind.path[b] = aux;
    }
    private static void shift(Random rmd, cMP ind){
        int a =  rmd.nextInt(ind.path.length);
        int b =  rmd.nextInt(ind.path.length);
        int c =  rmd.nextInt(ind.path.length);
        int aux = ind.path[a];
        ind.path[a] = ind.path[b];
        ind.path[b] = ind.path[c];
        ind.path[c] = aux;
    }

}
