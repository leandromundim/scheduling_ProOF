/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ProOF.apl.sample1.problem.MP;

import ProOF.opt.abst.problem.meta.codification.Codification;

/**
 *
 * @author mundim
 */
public class cMP extends Codification<MP, cMP> {
    protected int path[];

    public cMP(MP prob) {
        this.path = new int[prob.inst.N];
    }
    @Override
    public void copy(MP prob, cMP source) throws Exception {
        System.arraycopy(source.path, 0, this.path, 0, this.path.length);
    }
    @Override
    public cMP build(MP prob) throws Exception {
        return new cMP(prob);
    }
}
